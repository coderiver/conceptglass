<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'conceptglass');

/** Имя пользователя MySQL */
define('DB_USER', 'root');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'root');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'cQ1M-#F+W]Cc~,z2$=}8+]/:.sM]E8E73}z7aFxT!!@+k#_8PQ7*0yDStTk|QwL-');
define('SECURE_AUTH_KEY',  ';FW[mcM&;j^-MKY~$YuE;v<Z*.BZJz}iYoighB3a|}]_3(M+SM`<A[n^ei 14^$W');
define('LOGGED_IN_KEY',    '@Toy+Pg3qq9+B&yJjU/l+<VR@QQ y?.R-?tgE1;yXQbDEPq9Wzn`lqcK5bmar>{%');
define('NONCE_KEY',        '_M=+Q1VPlK~<SPKv!~FZw6KZMlzzhfP=6*E+n+`px@|PM|<B}b#Z*zW?w9%DVYjo');
define('AUTH_SALT',        '-QVf3%mX9*!r|Jzj/QD2:,rsxVtcj=>UyflGyRn1Vo+Oj1Zt7 <72U-d0PZ^Cf9X');
define('SECURE_AUTH_SALT', 'erjUUI(N+UXi$ U!SK4sq{4+HQ6;Qg0h>u2N}?F+WRzKiiala&>UyTxk3jEu4~gK');
define('LOGGED_IN_SALT',   'y[y|GT&z>)f0 X(X3V-Tf0UCaJ>nD{>^fE,)D3%^)h#GhsqG,x0RJGP^?0$TkAad');
define('NONCE_SALT',       ' MGp;$WT3&H+L,SD}Y_?}H1+kSOXW&$ok$?*kW? )N)O|KZCg663)2H~4qO3K<bV');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 * 
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
